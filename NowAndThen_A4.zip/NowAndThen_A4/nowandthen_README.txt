Andrew Vohl - ACV563
Hanah Luong - HKL289
Aaron "boss" Dishman - adishman

The app will align, superimpose, and then edit a previous taken picture of a location, or a well known photo of a landmark in real time with a brand new photo. You'll be prompted with options to superimpose a photo recently taken that you forgot to do back than, or take a fresh photo. the other photo will then be picked based off your geo location, or your own choice. The user will be prompted with several edit functions to align before the snap and then several more to customize after. From shaders to cutouts, the user will be able to make his own custom blended picture of now and then.

Features completed
-camera implemented

Features to implement
-Social integration
-alignment prior to snap
-edit cut-outs after snap
-shaders/blending of colors across image for authenticity
-geo tag sort on old photos in users library for superimposing
-web search for landmark images based on location

Got camera implementation from tutorial on Android Hive.
isDeviceSupportCamera()
captureImage()
onSaveInstanceState()
onRestoreInstanceState()
onActivityResult()
previewCaptureImage()
getOutputMediaFileURI()
getOutputMediaFile()

http://www.androidhive.info/2013/09/android-working-with-camera-api/

The layout and structure of the app was implemented by us. 